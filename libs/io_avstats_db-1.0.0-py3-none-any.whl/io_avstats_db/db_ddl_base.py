# Copyright (c) 2022 IO-Aero. All rights reserved. Use of this
# source code is governed by the IO-Aero License, that can
# be found in the LICENSE.md file.

"""Managing the database schema of the PostgreSQL database."""
from psycopg.errors import DuplicateDatabase
from psycopg.errors import DuplicateObject

from io_avstats_db import db_utils
from io_avstats_db import io_config
from io_avstats_db import io_glob
from io_avstats_db import io_utils

DLL_STMNTS: dict[str, str] = {}

# ------------------------------------------------------------------
# Setting up the database schema.
# ------------------------------------------------------------------
def create_db_schema() -> None:
    """Setting up the database schema."""
    io_glob.logger.debug(io_glob.LOGGER_START)

    conn, cur = db_utils.get_postgres_cursor_admin()

    try:
        cur.execute(
            f"CREATE USER {io_config.settings.postgres_user} WITH CREATEDB LOGIN "
            + f"PASSWORD '{io_config.settings.postgres_password}'"
        )

        # INFO.00.016 Database user is available: {user}
        io_utils.progress_msg(
            io_glob.INFO_00_016.replace("{user}", io_config.settings.postgres_user),
        )
    except DuplicateObject:
        pass

    try:
        cur.execute(
            f"CREATE DATABASE {io_config.settings.postgres_dbname} "
            + f"WITH OWNER {io_config.settings.postgres_user}"
        )

        # INFO.00.017 Database is available: {dbname}
        io_utils.progress_msg(
            io_glob.INFO_00_017.replace("{dbname}", io_config.settings.postgres_dbname),
        )
    except DuplicateDatabase:
        pass

    cur.close()
    conn.close()

    conn, cur = db_utils.get_postgres_cursor()

    get_ddl_base()
    get_io_msaccess_file()

    for table, stmnt in DLL_STMNTS.items():
        cur.execute(stmnt)
        conn.commit()
        # INFO.00.007 Database table created: {table}
        io_utils.progress_msg(
            io_glob.INFO_00_007.replace("{table}", table),
        )

    cur.close()
    conn.close()

    io_glob.logger.debug(io_glob.LOGGER_END)


# ------------------------------------------------------------------
# Dropping the database schema.
# ------------------------------------------------------------------
def drop_db_schema() -> None:
    """Dropping the database schema."""
    io_glob.logger.debug(io_glob.LOGGER_START)

    conn, cur = db_utils.get_postgres_cursor_admin()

    cur.execute(f"DROP DATABASE IF EXISTS {io_config.settings.postgres_dbname}")

    # INFO.00.019 Database is dropped: {dbname}
    io_utils.progress_msg(
        io_glob.INFO_00_019.replace("{dbname}", io_config.settings.postgres_dbname),
    )

    cur.execute(f"DROP USER IF EXISTS {io_config.settings.postgres_user}")

    # INFO.00.018 Database user is dropped: {user}
    io_utils.progress_msg(
        io_glob.INFO_00_018.replace("{user}", io_config.settings.postgres_user),
    )

    cur.close()
    conn.close()

    io_glob.logger.debug(io_glob.LOGGER_END)


# ------------------------------------------------------------------
# Returns the DDL instructions for setting up the database schema.
# ------------------------------------------------------------------
# flake8: noqa: E501
def get_ddl_base() -> None:
    """Returns the DDL instructions for setting up the database schema."""
    io_glob.logger.debug(io_glob.LOGGER_START)

    # ------------------------------------------------------------------
    # Level 1 - without FK
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # MS Access: Country                                          LEGACY
    # dll_stmnts[
    #     "country"
    # ] = """
    #     create table if not exists country
    #     (
    #         country_code varchar(3),
    #         country_name varchar(50)
    #     );
    # """

    # ------------------------------------------------------------------
    # MS Access: ct_iaids                                         LEGACY
    # dll_stmnts[
    #     "ct_iaids"
    # ] = """
    #     create table if not exists ct_iaids
    #     (
    #         ct_name          varchar(22),
    #         code_iaids       varchar(4),
    #         meaning          varchar(50),
    #         seq              smallint,
    #         ntsb_type        varchar(1),
    #         ntsb_code        varchar(2),
    #         avn_code         varchar(5),
    #         ntsb_codes_more  varchar(11),
    #         not_for_ntsb_use boolean not null,
    #         eadms_use        boolean not null,
    #         notes            varchar(50)
    #     );
    # """

    # ------------------------------------------------------------------
    # MS Access: ct_seqevt                                        LEGACY
    # dll_stmnts[
    #     "ct_seqevt"
    # ] = """
    #     create table if not exists ct_seqevt
    #     (
    #         code    int,
    #         meaning varchar(50)
    #     );
    # """

    # ------------------------------------------------------------------
    # MS Access: eADMSPUB_DataDictionary                          LEGACY
    # dll_stmnts[
    #     "eadmspub_datadictionary"
    # ] = """
    #     create table if not exists eadmspub_datadictionary
    #     (
    #         "category of data" varchar(255),
    #         "table"            varchar(255),
    #         "column"           varchar(255),
    #         ct_name            varchar(255),
    #         code_iaids         varchar(255),
    #         meaning            varchar(255),
    #         "data type eadms"  varchar(255),
    #         "length eadms"     float,
    #         short_desc         varchar(255),
    #         question_def       text,
    #         "code meaning"     text,
    #         typeofchange       varchar(25),
    #         change_notes       text
    #     );
    # """

    # ------------------------------------------------------------------
    # MS Access: events
    DLL_STMNTS[
        "events"
    ] = """
        create table if not exists events
        (
            ev_id               varchar(14),
            ntsb_no             varchar(10),
            ev_type             varchar(3),
            ev_date             timestamp,
            ev_dow              varchar(2),
            ev_time             smallint,
            ev_tmzn             varchar(3),
            ev_city             varchar(50),
            ev_state            varchar(2),
            ev_country          varchar(4),
            ev_site_zipcode     varchar(10),
            ev_year             smallint,
            ev_month            smallint,
            mid_air             varchar(1),
            on_ground_collision varchar(1),
            latitude            varchar(7),
            longitude           varchar(8),
            latlong_acq         varchar(4),
            apt_name            varchar(30),
            ev_nr_apt_id        varchar(4),
            ev_nr_apt_loc       varchar(4),
            apt_dist            real,
            apt_dir             smallint,
            apt_elev            smallint,
            wx_brief_comp       varchar(4),
            wx_src_iic          varchar(4),
            wx_obs_time         smallint,
            wx_obs_dir          smallint,
            wx_obs_fac_id       varchar(4),
            wx_obs_elev         int,
            wx_obs_dist         smallint,
            wx_obs_tmzn         varchar(3),
            light_cond          varchar(4),
            sky_cond_nonceil    varchar(4),
            sky_nonceil_ht      int,
            sky_ceil_ht         int,
            sky_cond_ceil       varchar(4),
            vis_rvr             real,
            vis_rvv             smallint,
            vis_sm              real,
            wx_temp             smallint,
            wx_dew_pt           smallint,
            wind_dir_deg        smallint,
            wind_dir_ind        varchar(1),
            wind_vel_kts        smallint,
            wind_vel_ind        varchar(4),
            gust_ind            varchar(1),
            gust_kts            smallint,
            altimeter           real,
            wx_dens_alt         int,
            wx_int_precip       varchar(3),
            metar               text,
            ev_highest_injury   varchar(4),
            inj_f_grnd          smallint,
            inj_m_grnd          smallint,
            inj_s_grnd          smallint,
            inj_tot_f           smallint,
            inj_tot_m           smallint,
            inj_tot_n           smallint,
            inj_tot_s           smallint,
            inj_tot_t           smallint,
            invest_agy          varchar(1),
            ntsb_docket         int,
            ntsb_notf_from      varchar(30),
            ntsb_notf_date      timestamp,
            ntsb_notf_tm        smallint,
            fiche_number        varchar(5),
            lchg_date           timestamp,
            lchg_userid         varchar(18),
            wx_cond_basic       varchar(3),
            faa_dist_office     varchar(50),
            dec_latitude        float,
            dec_longitude       float,
            primary key (ev_id)
        );
    """

    # ------------------------------------------------------------------
    # MS Access: states                                           LEGACY
    # dll_stmnts[
    #     "states"
    # ] = """
    #     create table if not exists states
    #     (
    #         state      varchar(2),
    #         name       varchar(30),
    #         faa_region varchar(2)
    #     );
    # """

    # ------------------------------------------------------------------
    # Level 2 - FK ev_id
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # MS Access: aircraft
    DLL_STMNTS[
        "aircraft"
    ] = """
        create table if not exists aircraft
        (
            ev_id                   varchar(14),
            aircraft_key            int,
            regis_no                varchar(11),
            ntsb_no                 varchar(11),
            acft_missing            varchar(1),
            far_part                varchar(4),
            flt_plan_filed          varchar(4),
            flight_plan_activated   varchar(1),
            damage                  varchar(4),
            acft_fire               varchar(4),
            acft_expl               varchar(4),
            acft_make               varchar(30),
            acft_model              varchar(20),
            acft_series             varchar(10),
            acft_serial_no          varchar(20),
            cert_max_gr_wt          int,
            acft_category           varchar(4),
            acft_reg_cls            varchar(4),
            homebuilt               varchar(3),
            fc_seats                int,
            cc_seats                int,
            pax_seats               int,
            total_seats             smallint,
            num_eng                 smallint,
            fixed_retractable       varchar(4),
            type_last_insp          varchar(4),
            date_last_insp          timestamp,
            afm_hrs_last_insp       real,
            afm_hrs                 real,
            elt_install             varchar(1),
            elt_oper                varchar(1),
            elt_aided_loc_ev        varchar(1),
            elt_type                varchar(4),
            owner_acft              varchar(50),
            owner_street            varchar(50),
            owner_city              varchar(50),
            owner_state             varchar(2),
            owner_country           varchar(4),
            owner_zip               varchar(10),
            oper_individual_name    varchar(1),
            oper_name               varchar(50),
            oper_same               varchar(1),
            oper_dba                varchar(50),
            oper_addr_same          varchar(1),
            oper_street             varchar(50),
            oper_city               varchar(50),
            oper_state              varchar(2),
            oper_country            varchar(4),
            oper_zip                varchar(10),
            oper_code               varchar(4),
            certs_held              varchar(1),
            oprtng_cert             varchar(3),
            oper_cert               varchar(4),
            oper_cert_num           varchar(11),
            oper_sched              varchar(4),
            oper_dom_int            varchar(3),
            oper_pax_cargo          varchar(4),
            type_fly                varchar(4),
            second_pilot            varchar(1),
            dprt_pt_same_ev         varchar(1),
            dprt_apt_id             varchar(4),
            dprt_city               varchar(50),
            dprt_state              varchar(2),
            dprt_country            varchar(3),
            dprt_time               smallint,
            dprt_timezn             varchar(3),
            dest_same_local         varchar(4),
            dest_apt_id             varchar(4),
            dest_city               varchar(50),
            dest_state              varchar(2),
            dest_country            varchar(3),
            phase_flt_spec          int,
            report_to_icao          varchar(1),
            evacuation              varchar(1),
            lchg_date               timestamp,
            lchg_userid             varchar(18),
            afm_hrs_since           varchar(4),
            rwy_num                 varchar(4),
            rwy_len                 int,
            rwy_width               int,
            site_seeing             varchar(1),
            air_medical             varchar(1),
            med_type_flight         varchar(15),
            acft_year               int,
            fuel_on_board           varchar(20),
            commercial_space_flight boolean not null,
            unmanned                boolean not null,
            ifr_equipped_cert       boolean not null,
            elt_mounted_aircraft    boolean not null,
            elt_connected_antenna   boolean not null,
            elt_manufacturer        varchar(50),
            elt_model               varchar(50),
            elt_reason_other        text,
            primary key (ev_id, aircraft_key),
            foreign key (ev_id) references events (ev_id) on delete cascade
        );
    """

    # ------------------------------------------------------------------
    # MS Access: dt_events
    DLL_STMNTS[
        "dt_events"
    ] = """
        create table if not exists dt_events
        (
            ev_id       varchar(14),
            col_name    varchar(20),
            code        varchar(4),
            lchg_date   timestamp,
            lchg_userid varchar(18),
            primary key (ev_id, col_name, code),
            foreign key (ev_id) references events (ev_id) on delete cascade
        );
    """

    # ------------------------------------------------------------------
    # MS Access: NTSB_Admin
    DLL_STMNTS[
        "ntsb_admin"
    ] = """
        create table if not exists ntsb_admin
        (
            ev_id         varchar(14),
            rec_stat      varchar(1),
            approval_date timestamp,
            lchg_userid   varchar(18),
            lchg_date     timestamp,
            primary key (ev_id)
        );
    """

    # ------------------------------------------------------------------
    # Level 3 - FKs ev_id & aircraft_key
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # MS Access: dt_aircraft
    DLL_STMNTS[
        "dt_aircraft"
    ] = """
        create table if not exists dt_aircraft
        (
            ev_id        varchar(14),
            aircraft_key int,
            col_name     varchar(20),
            code         varchar(4),
            lchg_date    timestamp,
            lchg_userid  varchar(18),
            primary key (ev_id, aircraft_key, col_name, code),
            foreign key (ev_id) references events (ev_id) on delete cascade,
            foreign key (ev_id, aircraft_key) references aircraft (ev_id, aircraft_key) on delete cascade
        );
    """

    # ------------------------------------------------------------------
    # MS Access: engines
    DLL_STMNTS[
        "engines"
    ] = """
        create table if not exists engines
        (
            ev_id               varchar(14),
            aircraft_key        int,
            eng_no              smallint,
            eng_type            varchar(4),
            eng_mfgr            varchar(30),
            eng_model           varchar(13),
            power_units         int,
            hp_or_lbs           varchar(4),
            lchg_userid         varchar(18),
            lchg_date           timestamp,
            carb_fuel_injection varchar(4),
            propeller_type      varchar(4),
            propeller_make      varchar(50),
            propeller_model     varchar(50),
            eng_time_total      real,
            eng_time_last_insp  real,
            eng_time_overhaul   real,
            primary key (ev_id, aircraft_key, eng_no),
            foreign key (ev_id) references events (ev_id) on delete cascade,
            foreign key (ev_id, aircraft_key) references aircraft (ev_id, aircraft_key) on delete cascade
        );
    """

    # ------------------------------------------------------------------
    # MS Access: Events_Sequence                                   EMPTY
    DLL_STMNTS[
        "events_sequence"
    ] = """
        create table if not exists events_sequence
        (
            ev_id                  varchar(14),
            aircraft_key           int,
            occurrence_no          int,
            occurrence_code        varchar(7),
            occurrence_description varchar(100),
            phase_no               varchar(3),
            eventsoe_no            varchar(3),
            defining_ev            boolean not null,
            lchg_date              timestamp,
            lchg_userid            varchar(18),
            primary key (ev_id, aircraft_key, occurrence_no),
            foreign key (ev_id) references events (ev_id) on delete cascade,
            foreign key (ev_id, aircraft_key) references aircraft (ev_id, aircraft_key) on delete cascade
        );
    """

    # ------------------------------------------------------------------
    # MS Access: Findings
    DLL_STMNTS[
        "findings"
    ] = """
        create table if not exists findings
        (
            ev_id               varchar(14),
            aircraft_key        int,
            finding_no          int,
            finding_code        varchar(10),
            finding_description varchar(255),
            category_no         varchar(2),
            subcategory_no      varchar(2),
            section_no          varchar(2),
            subsection_no       varchar(2),
            modifier_no         varchar(2),
            cause_factor        varchar(1),
            lchg_date           timestamp,
            lchg_userid         varchar(50),
            primary key (ev_id, aircraft_key, finding_no),
            foreign key (ev_id) references events (ev_id) on delete cascade,
            foreign key (ev_id, aircraft_key) references aircraft (ev_id, aircraft_key) on delete cascade
        );
    """

    # ------------------------------------------------------------------
    # MS Access: Flight_Crew
    DLL_STMNTS[
        "flight_crew"
    ] = """
        create table if not exists flight_crew
        (
            ev_id               varchar(14),
            aircraft_key        int,
            crew_no             smallint,
            crew_category       varchar(5),
            crew_age            smallint,
            crew_sex            varchar(1),
            crew_city           varchar(15),
            crew_res_state      varchar(2),
            crew_res_country    varchar(4),
            med_certf           varchar(4),
            med_crtf_vldty      varchar(4),
            date_lst_med        timestamp,
            crew_rat_endorse    varchar(1),
            crew_inj_level      varchar(4),
            seatbelts_used      varchar(1),
            shldr_harn_used     varchar(1),
            crew_tox_perf       varchar(1),
            seat_occ_pic        varchar(4),
            pc_profession       varchar(4),
            bfr                 varchar(1),
            bfr_date            timestamp,
            ft_as_of            timestamp,
            lchg_date           timestamp,
            lchg_userid         varchar(18),
            seat_occ_row        int,
            infl_rest_inst      varchar(1),
            infl_rest_depl      varchar(1),
            child_restraint     varchar(3),
            med_crtf_limit      text,
            mr_faa_med_certf    varchar(4),
            pilot_flying        boolean not null,
            available_restraint varchar(1),
            restraint_used      varchar(1),
            primary key (ev_id, aircraft_key, crew_no),
            foreign key (ev_id) references events (ev_id) on delete cascade,
            foreign key (ev_id, aircraft_key) references aircraft (ev_id, aircraft_key) on delete cascade
        );
    """

    # ------------------------------------------------------------------
    # MS Access: injury
    DLL_STMNTS[
        "injury"
    ] = """
        create table if not exists injury
        (
            ev_id               varchar(14),
            aircraft_key        int,
            inj_person_category varchar(4),
            injury_level        varchar(4),
            inj_person_count    smallint,
            lchg_date           timestamp,
            lchg_userid         varchar(18),
            primary key (ev_id, aircraft_key, inj_person_category, injury_level),
            foreign key (ev_id) references events (ev_id) on delete cascade,
            foreign key (ev_id, aircraft_key) references aircraft (ev_id, aircraft_key) on delete cascade
        );
    """

    # ------------------------------------------------------------------
    # MS Access: narratives
    DLL_STMNTS[
        "narratives"
    ] = """
        create table if not exists narratives
        (
            ev_id        varchar(14),
            aircraft_key int,
            narr_accp    text,
            narr_accf    text,
            narr_cause   text,
            narr_inc     text,
            lchg_date    timestamp,
            lchg_userid  varchar(18),
            primary key (ev_id, aircraft_key),
            foreign key (ev_id) references events (ev_id) on delete cascade,
            foreign key (ev_id, aircraft_key) references aircraft (ev_id, aircraft_key) on delete cascade
        );
    """

    # ------------------------------------------------------------------
    # MS Access: Occurrences
    DLL_STMNTS[
        "occurrences"
    ] = """
        create table if not exists occurrences
        (
            ev_id           varchar(14),
            aircraft_key    int,
            occurrence_no   int,
            occurrence_code int,
            phase_of_flight int,
            altitude        int,
            lchg_date       timestamp,
            lchg_userid     varchar(18),
            primary key (ev_id, aircraft_key, occurrence_no),
            foreign key (ev_id) references events (ev_id) on delete cascade,
            foreign key (ev_id, aircraft_key) references aircraft (ev_id, aircraft_key) on delete cascade
        );
    """

    # ------------------------------------------------------------------
    # Level 4 - FKs ev_id & aircraft_key & crew_no
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # MS Access: dt_Flight_Crew
    DLL_STMNTS[
        "dt_flight_crew"
    ] = """
        create table if not exists dt_flight_crew
        (
            ev_id        varchar(14),
            aircraft_key int,
            crew_no      smallint,
            col_name     varchar(20),
            code         varchar(4),
            lchg_date    timestamp,
            lchg_userid  varchar(18),
            primary key (ev_id, aircraft_key, crew_no, col_name, code),
            foreign key (ev_id) references events (ev_id) on delete cascade,
            foreign key (ev_id, aircraft_key) references aircraft (ev_id, aircraft_key) on delete cascade,
            foreign key (ev_id, aircraft_key, crew_no) references flight_crew (ev_id, aircraft_key, crew_no) on delete cascade
        );
    """

    # ------------------------------------------------------------------
    # MS Access: flight_time
    DLL_STMNTS[
        "flight_time"
    ] = """
        create table if not exists flight_time
        (
            ev_id        varchar(14),
            aircraft_key int,
            crew_no      smallint,
            flight_type  varchar(4),
            flight_craft varchar(4),
            flight_hours real,
            lchg_date    timestamp,
            lchg_userid  varchar(18),
            primary key (ev_id, aircraft_key, crew_no, flight_type, flight_craft),
            foreign key (ev_id) references events (ev_id) on delete cascade,
            foreign key (ev_id, aircraft_key) references aircraft (ev_id, aircraft_key) on delete cascade,
            foreign key (ev_id, aircraft_key, crew_no) references flight_crew (ev_id, aircraft_key, crew_no) on delete cascade
        );
    """

    # ------------------------------------------------------------------
    # Level 4 - FKs ev_id & aircraft_key & occurrence_no
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # MS Access: seq_of_events                                     EMPTY
    DLL_STMNTS[
        "seq_of_events"
    ] = """
        create table if not exists seq_of_events
        (
            ev_id         varchar(14),
            aircraft_key  int,
            occurrence_no int,
            seq_event_no  int,
            group_code    smallint,
            subj_code     int,
            cause_factor  varchar(1),
            modifier_code int,
            person_code   int,
            lchg_date     timestamp,
            lchg_userid   varchar(18),
            primary key (ev_id, aircraft_key, occurrence_no, seq_event_no, group_code),
            foreign key (ev_id) references events (ev_id) on delete cascade,
            foreign key (ev_id, aircraft_key) references aircraft (ev_id, aircraft_key) on delete cascade
        );
    """

    io_glob.logger.debug(io_glob.LOGGER_END)


# ------------------------------------------------------------------
# Adds the DDL statement for setting up io_msaccess_file.
# ------------------------------------------------------------------
# flake8: noqa: E501
def get_io_msaccess_file() -> None:
    """Adds the DDL statement for setting up io_msaccess_file."""
    io_glob.logger.debug(io_glob.LOGGER_START)

    DLL_STMNTS[
        "io_msaccess_file"
    ] = """
        create table if not exists io_msaccess_file
        (
            file_name       varchar(63),
            first_processed timestamp NOT NULL,
            last_processed  timestamp,
            counter         int NOT NULL,
            primary key (file_name)
        );
    """

    io_glob.logger.debug(io_glob.LOGGER_END)
