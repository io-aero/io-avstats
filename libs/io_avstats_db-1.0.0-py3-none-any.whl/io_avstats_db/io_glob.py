# Copyright (c) 2022 IO-Aero. All rights reserved. Use of this
# source code is governed by the IO-Aero License, that can
# be found in the LICENSE.md file.

"""Global constants and variables."""
import logging.config

ARG_MSACCESS = "msaccess"
ARG_MSACCESS_AVALL = "avall"
ARG_MSACCESS_PRE2008 = "Pre2008"
ARG_MSACCESS_UPDDMON = "upDDMON"
ARG_TASK = "task"
ARG_TASK_C_D_S = "c_d_s"
ARG_TASK_D_D_S = "d_d_s"
ARG_TASK_D_M_A = "d_m_a"
ARG_TASK_GENERATE = "generate"
ARG_TASK_L_M_A = "l_m_a"
ARG_TASK_VERSION = "version"

# Error messages.
ERROR_00_901 = (
    "ERROR.00.901 The task '{task}' requires valid argument '-m' or '--msaccess'"
)
ERROR_00_902 = (
    "ERROR.00.902 The task '{task}' does not require an argument '-m' or '--msaccess'"
)
ERROR_00_903 = (
    "ERROR.00.903 '{msaccess}' is not a valid NTSB compliant MS Access database name"
)
ERROR_00_904 = (
    "ERROR.00.904 '{msaccess}': the MS Access database file name must not contain "
    + "a file extension"
)
ERROR_00_905 = "ERROR.00.905 Connection problem with url='{url}'"
ERROR_00_906 = "ERROR.00.906 Unexpected response status code='{status_code}'"
ERROR_00_907 = "ERROR.00.907 File '{filename}' is not a zip file"
ERROR_00_908 = "ERROR.00.908 The operating system '{os}' is not supported"
ERROR_00_909 = "ERROR.00.909 Timeout after '{timeout}' seconds with url='{url}'"
ERROR_00_910 = (
    "ERROR.00.910 The schema definition in file '{filename}' "
    + "does not match the reference definition in file '{reference}'"
)
ERROR_00_911 = (
    "ERROR.00.911 Number of lines differs: file '{filename}' lines {filename_lines}"
    + "versus file '{reference}' lines {reference_lines}"
)
ERROR_00_912 = "ERROR.00.912 The MS Access database file '{filename}' is missing"

# Default file encoding UTF-8.
FILE_ENCODING_DEFAULT = "utf-8"

FILE_EXTENSION_MDB = "mdb"
FILE_EXTENSION_SQL = "sql"
FILE_EXTENSION_ZIP = "zip"

# Informational messages.
INFO_00_001 = "INFO.00.001 The logger is configured and ready"
INFO_00_002 = (
    "INFO.00.002 The configuration parameters (io_avstats_db) are checked and loaded"
)
INFO_00_003 = (
    "INFO.00.003 Initialize the configuration parameters using the file '{file}'"
)
INFO_00_004 = "INFO.00.004 Start Launcher"
INFO_00_005 = "INFO.00.005 Argument {task}='{value_task}'"
INFO_00_006 = "INFO.00.006 End   Launcher"
INFO_00_007 = "INFO.00.007 Database table is available: {table}"
INFO_00_008 = (
    "INFO.00.008 Arguments {task}='{value_task}' {msaccess}='{value_msaccess}'"
)
INFO_00_009 = "INFO.00.009 line no.: {line_no}"
INFO_00_010 = "INFO.00.010 {status} '{line}'"
INFO_00_011 = (
    "INFO.00.011 The DDL script for the MS Access database "
    + "'{msaccess}.mdb' was created successfully"
)
INFO_00_012 = (
    "INFO.00.012 The DDL script for the MS Access database "
    + "'{msaccess}.mdb' is identical to the reference script"
)
INFO_00_013 = (
    "INFO.00.013 The connection to the MS Access database file "
    + "'{msaccess}.zip' on the NTSB download page was successfully established"
)
INFO_00_014 = (
    "INFO.00.014 From the file '{msaccess}.zip' {no_chunks} chunks were downloaded"
)
INFO_00_015 = "INFO.00.015 The file '{msaccess}.zip'  was successfully unpacked"
INFO_00_016 = "INFO.00.016 Database user is available: {user}"
INFO_00_017 = "INFO.00.017 Database is available: {dbname}"
INFO_00_018 = "INFO.00.018 Database user is dropped: {user}"
INFO_00_019 = "INFO.00.019 Database is dropped: {dbname}"
INFO_00_020 = (
    "INFO.00.020 The DDL script for the MS Access database "
    + "'{msaccess}.mdb' must be checked manually"
)
INFO_00_021 = "INFO.00.021 The following database table is not processed: '{msaccess}'"

INFORMATION_NOT_YET_AVAILABLE = "n/a"

# Library version number.
IO_AVSTATS_DB_VERSION = "1.0.0"

LOCALE = "en_US.UTF-8"
# Logging constants.
LOGGER_END = "End"
LOGGER_NAME = "io_avstats_db"
LOGGER_START = "Start"

# Microsoft Access database files.
MSACCESS_PRE2008 = "Pre2008"

# Database table names.
TABLE_NAME_AIRCRAFT = "aircraft"
TABLE_NAME_DT_AIRCRAFT = "dt_aircraft"
TABLE_NAME_DT_EVENTS = "dt_events"
TABLE_NAME_DT_FLIGHT_CREW = "dt_Flight_Crew"
TABLE_NAME_ENGINES = "engines"
TABLE_NAME_EVENTS = "events"
TABLE_NAME_EVENTS_SEQUENCE = "Events_Sequence"
TABLE_NAME_FINDINGS = "Findings"
TABLE_NAME_FLIGHT_CREW = "Flight_Crew"
TABLE_NAME_FLIGHT_TIME = "flight_time"
TABLE_NAME_INJURY = "injury"
TABLE_NAME_NARRATIVES = "narratives"
TABLE_NAME_NTSB_ADMIN = "NTSB_Admin"
TABLE_NAME_OCCURRENCES = "Occurrences"
TABLE_NAME_SEQ_OF_EVENTS = "seq_of_events"

# Logger instance.
logger: logging.Logger = logging.getLogger(LOGGER_NAME)
