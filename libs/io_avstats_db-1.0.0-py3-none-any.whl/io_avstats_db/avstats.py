# Copyright (c) 2022 IO-Aero. All rights reserved. Use of this
# source code is governed by the IO-Aero License, that can
# be found in the LICENSE.md file.

"""IO-AVSTATS-DB interface."""
from __future__ import annotations

from io_avstats_db import code_generator
from io_avstats_db import db_ddl_base
from io_avstats_db import db_dml_base
from io_avstats_db import io_config
from io_avstats_db import io_glob
from io_avstats_db import io_utils


# ------------------------------------------------------------------
# Create the database schema.
# ------------------------------------------------------------------
def create_db_schema() -> None:
    """Create the database schema."""
    io_glob.logger.debug(io_glob.LOGGER_START)

    db_ddl_base.create_db_schema()

    io_glob.logger.debug(io_glob.LOGGER_END)


# ------------------------------------------------------------------
# Download a Microsoft Access database file.
# ------------------------------------------------------------------
def download_msaccess_file(msaccess: str) -> None:
    """Download a Microsoft Access database file.

    Args:
        msaccess (str):
            The MS Access database file without file extension.
    """
    io_glob.logger.debug(io_glob.LOGGER_START)

    db_dml_base.download_msaccess_file(msaccess)

    io_glob.logger.debug(io_glob.LOGGER_END)


# ------------------------------------------------------------------
# Drop the database schema.
# ------------------------------------------------------------------
def drop_db_schema() -> None:
    """Drop the database schema."""
    io_glob.logger.debug(io_glob.LOGGER_START)

    db_ddl_base.drop_db_schema()

    io_glob.logger.debug(io_glob.LOGGER_END)


# -----------------------------------------------------------------------------
# Generate SQL statements: INSERT & UPDATE.
# -----------------------------------------------------------------------------
def generate_sql() -> None:
    """Generate SQL statements: INSERT & UPDATE."""
    io_glob.logger.debug(io_glob.LOGGER_START)

    code_generator.generate_sql()

    io_glob.logger.debug(io_glob.LOGGER_END)


# -----------------------------------------------------------------------------
# Initialising the logging functionality.
# -----------------------------------------------------------------------------
def initialise_logger() -> None:
    """Initialise the root logging functionality."""
    io_utils.initialise_logger()


# ------------------------------------------------------------------
# Load data from Microsoft Access to the PostgreSQL database.
# ------------------------------------------------------------------
def load_msaccess_data(msaccess: str) -> None:
    """Load data from Microsoft Access to the PostgreSQL database.

    Args:
        msaccess (str):
            The MS Access database file without file extension.
    """
    io_glob.logger.debug(io_glob.LOGGER_START)

    db_dml_base.load_msaccess_data(msaccess)

    io_glob.logger.debug(io_glob.LOGGER_END)


# ------------------------------------------------------------------
# Create a progress message.
# ------------------------------------------------------------------
def progress_msg(msg: str) -> None:
    """Create a progress message.

    Args:
        msg (str): Progress message
    """
    if io_config.settings.is_verbose:
        io_utils.progress_msg_core(msg)


# ------------------------------------------------------------------
# Create a progress message.
# ------------------------------------------------------------------
def progress_msg_time_elapsed(duration: int, event: str) -> None:
    """Create a time elapsed message.

    Args:
        duration (int): Time elapsed in ns
        event (str): Event
    """
    io_utils.progress_msg_time_elapsed(duration, event)


# ------------------------------------------------------------------
# Terminate the application immediately.
# ------------------------------------------------------------------
def terminate_fatal(error_msg: str) -> None:
    """Terminate the application immediately.

    Args:
        error_msg (str): Error message
    """

    io_utils.terminate_fatal(error_msg)


# ------------------------------------------------------------------
# Returns the version number of the IO-AVSTATS-DB application.
# ------------------------------------------------------------------
def version() -> str:
    """Returns the version number of the IO-AVSTATS-DB application.

    Returns:
        str:
            The version number of the IO-AVSTATS-DB application
    """
    io_glob.logger.debug(io_glob.LOGGER_START)
    io_glob.logger.debug(io_glob.LOGGER_END)

    return io_glob.IO_AVSTATS_DB_VERSION
